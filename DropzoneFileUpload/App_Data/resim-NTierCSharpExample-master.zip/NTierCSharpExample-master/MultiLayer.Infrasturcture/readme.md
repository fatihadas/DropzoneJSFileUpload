#INFRASTRUCTURE

All The use of external data, like DB, File, Webservices etc. must be placed here.