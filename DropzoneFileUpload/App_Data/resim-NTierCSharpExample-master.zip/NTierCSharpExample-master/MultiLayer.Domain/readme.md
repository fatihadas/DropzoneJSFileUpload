#Domain Classes

These are our core bussiness classes.

What will be come here is:

- Pure Entity Classes (POCO Classes) (e.g. Customer, Book, etc.)
- Interfaces to CRUD of Entity Classes






