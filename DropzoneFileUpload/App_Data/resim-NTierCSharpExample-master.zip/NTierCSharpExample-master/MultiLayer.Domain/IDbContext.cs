﻿using System;

namespace MultiLayer.Domain
{
    public interface IDbContext : IDisposable
    {
    }
}
