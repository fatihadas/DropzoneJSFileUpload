﻿#SERVICES

This Layer is a proxy between our presentation and Infrastructure.
Here we can do our business operations, before data sent to be persist.

Also we can have a Web API Project here, so we can use this as a way to service to multiple User Interfaces, like desktop, mobile etc.