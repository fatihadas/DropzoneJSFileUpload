NTierCSharpExample
==================

This is an Example of NTier CSharp Application That Used Repository Pattern and Onion Architecture By "Jeffrey Palermo". This Example Can be used as template for enterprice application by little extending. It Can be Used as a base template for any ASP.NET MVC application. In This Template Entity Framework 6 as ORM, an Ninject 3.x as Dependency Injection Tool Used.


You can simply unplug the presentation project and add your own presentation project. 
